#Readme
This Android app, QuizBee, was developed as a learning project using Android Studio 2.1.

Introduction
QuizBee is an interactive quiz application designed for Android devices. It allows users to test their knowledge of the Java programming language through a series of multiple-choice questions. The app provides a user-friendly interface, making it easy for users to answer the questions and track their progress. At the end of the quiz, a comprehensive result report is generated, providing the user with their final score. Additionally, the app offers the option to replay the quiz or exit at any point.

Features
The QuizBee app consists of four main activities:

Main: This activity serves as the home screen of the application, providing an overview and navigation options.
Questions: In this activity, users are presented with multiple-choice questions and can track their current score.
Results: After completing the quiz, users are shown a summary of their results, including their final score.
Developers: This activity provides information about the developers of the QuizBee app.
Screenshots
Home Screen(image)
Question Activity(image)
Results Activity(image)
## ContactIf you have any queries, suggestions, or feedback, please feel free to reach out via email: girmaefrem6@gmail.com.Contributions and pull requests are also welcome to further enhance the application and make it more professional.

                 Group Members 

            Name               ID
	1, Efrem Gimra     Ugr/10388/13
	2, Abel Boke       Ugr/9813/13
	3, Awel Husen      Ugr/11363/13
	4, Ahimed Kedir    Ugr/9916/13
	5, Marenew Simggnaw Ugr/10676/13
	6, Fuad Abubeker    Ugr/11497/13
